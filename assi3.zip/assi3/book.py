class book:

    def __init__(self):
        self.author=input("Enter author name: ")
        self.publisher=input("Enter publisher name: ")
        self.price=int(input("Enter price: "))
        self.author_royalty=int(input("Enter royalty "))
        self.copies=int(input("Enter copies: "))


    def get_book(self):
        return print(self.author, self.publisher, self.price, self.author_royalty, self.copies)

    def set_book(self,a,pub,pr,ar,c):
        self.author=a
        self.publisher=pub
        self.price=pr
        self.author_royalty=ar
        self.copies=c
        return

    def royalty(self):
        self.retail_price = self.price * self.copies
        if self.copies>=500:
            self.retail_price= self.retail_price * 10 / 100 + self.retail_price
            if self.copies>=1000:
                self.retail_price = self.retail_price * 12.5/100 + self.retail_price
                if self.copies>1000:
                    self.retail_price = self.retail_price * 15/100 + self.retail_price

        print("Expected price",self.retail_price)

b=book()
#b.get_book()
b.royalty()
b.get_book()
#b.set_book("roni","munga",1,10,1000)
#b.get_book()
#b.royalty()

class Ebook(book):
    def __init__(self):
        self.price=int(input("Enter price"))
        self.copies = int(input("Enter copies"))
    def royalty(self):
        self.retail_price = self.price * self.copies
        if self.copies>=500:
            self.retail_price= self.retail_price * 10 / 100 + self.retail_price
            if self.copies>=1000:
                self.retail_price = self.retail_price * 12.5/100 + self.retail_price
                if self.copies>1000:
                    self.retail_price = self.retail_price * 15/100 + self.retail_price

        print("Expected price",self.retail_price)
        self.retail_price = self.retail_price - self.retail_price * 12/100
        print("After cutting 12% gst",self.retail_price)
        return

c=Ebook()
c.royalty()