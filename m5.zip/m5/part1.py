import sqlite3

db=sqlite3.connect("KITAB.DB")

cur=db.cursor()

cur.execute("""CREATE TABLE IF NOT EXISTS BOOKS (BOOKID INTEGER PRIMARY KEY AUTOINCREMENT,
TITTLE TEXT (50) NOT NULL,
AUTHOR TEXT(20),
PRICE FLOAT NOT NULL);""")

while (True):
    print("Insert book details")
    ttl=input("enter books title:")
    aut=input("enter name of author: ")
    pr=float(input("enter price: "))

    try:
        cur.execute("INSERT INTO BOOKS(TITTLE,AUTHOR,PRICE) VALUES(?,?,?)",(ttl,aut,pr))
        db.commit()

        print("Book added successfully")
    except:
        print("error in operation")
        db.rollback()

    rep=input("Add more books ? Y/N: ")
    if rep=='Y'or rep=="y":
        continue
    else:
        break
db.close()
