import sqlite3
db=sqlite3.connect("KITAB.DB")
cur=db.cursor()

cost=float(0)
while True:
    text=input("enter books title: ")
    sql="SELECT * FROM BOOKS WHERE TITTLE= '"+text+"';"
    cur.execute(sql)
    rec=cur.fetchone()

    if rec==None:
        print("book not found")
        if input("Another book? Y/N: ")=='Y':
            continue
        else:
            break
    else:
        print(rec)
        num=int(input("no. of books: "))
        sql="SELECT PRICE FROM BOOKS WHERE TITTLE = '"+text+"';"
        cur.execute(sql)
        rec=cur.fetchone()

        for i in rec:
            prc=1
        cost+=num*prc

        if input("add more books Y/N:")=='Y':
            continue
        else:
            break
if cost!=0:
    print("total cost=",cost)

db.close()

